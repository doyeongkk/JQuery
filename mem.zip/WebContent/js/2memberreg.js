/**
 * 
 */

function idcheck(){
	idvalue= $('#id').val().trim();
	
	// 공백체크
	
	if(idvalue.length <1){
		alert("아이디입력");
		return false;
	}
	// 아이디 길이 - 4~ 12
	  if(idvalue.length <4 || idvalue.length >12){
		  alert("아이디 4~12");
		  return false;
	  }
	
	// 아이디 정규식 - 소문자로 시작하고 대문자와 숫자로 조합가능
	  idreg = /^[a-z][a-zA-Z0-9]{3,7}$/;
	  if(!(idreg.test(idvalue))){
		  alert("아이디 형식 오류 ");
		  return false;
	  }
	  
	  return true;
}

function regcheck(){
	
	// 이름- 공백, 길이, 정규식 -한글 2~5입력
	nvalue= $('#name').val().trim();
	
	// 이름 공백체크
	if(nvalue.length <1){
		alert("이름입력");
		return false;
	}
	
	//이름 길이 2~5 
	 if(nvalue.length <2 || nvalue.length >5){
		  alert("이름 2~5");
		  return false;
	  }
	 
	 // 이름 정규식 -한글
	 namereg = /^[가-힣]{2,5}$/;
	 if(!(namereg.test(nvalue))){
	  alert("이름 형식 오류 ");
	  return false;
  }
	 
	 // 생년월일 - 10살 이상 정규식	
	 birvalue = $('#bir').val().trim();
	 sub = parseInt(birvalue.substr(0,4));
	 age = 2020 - sub;
	 if(sub.length < 1){
	     alert("생년월일을 입력해주세요" + bvalue);
	     return false;
		 
	 }
	
	 if(age<10){
		 alert("당신의 나이는" + age + "살 입니다.가입이 불가합니다.");
		 return false;
	 }
	 
	 
  
	
	// 비밀번호- 공백, 길이 정규식 -영문대소문자 숫자 특수문자가 하나이상씩 8~12 입력
	 pvalue= $('#pwd').val().trim();
	 pvalue1= $('#pwdck').val().trim();
	 
	// 공백 
	 if(pvalue.length <1){
			alert("비밀번호입력");
			return false;
		}
	//길이 정규식
	 if(pvalue.length <8 || pvalue.length >12){
		  alert("비밀번호 8~12");
		  return false;
	  }
	 
	 
	 
	// 비밀번호 정규식 -영문대소문자 숫자 특수문자가 하나이상씩 8~12 입력
	 pwdreg = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,12}$/;
	 if(!(pwdreg.test(pvalue))){
		  alert("비밀번호 형식 오류 ");
		  return false;
	  }
	 
	    	 
	 // 비밀번호 확인 
	 if(pvalue != pvalue1){
		 alert("비밀번호가 맞지 않습니다.");
		 return false;
	 }
	 
	 
	 
	 
	 
	// 전화번호 
	 telvalue= $('#tel').val().trim();
	
	 
	 //공백
	 if(telvalue.length < 1){
			alert("전화번호입력");
			return false;
		}
	 
	 
	 // 전화번호 정규식 
	 telreg= /^\d{3}-\d{4}-\d{4}$/;
	  if(!(telreg.test(telvalue))){
      	alert("전화번호 형식 오류");
      	return false;
      } 
      
	  
	 
	
	// 이메일 - 공백 정규식
	  mvalue = $('#mail').val().trim();
	  // 공백
	  
	  
		 if(mvalue.length <1){
				alert("이메일입력");
				return false;
			}
      // 길이 정규식		 
		 if(mvalue <1) {
	  		  alert("이메일 입력");
	  		  return false;
	  	  }
	  // 이메일 정규식 abc-123@kk123.com , ASDFas12@hgg.co.kr
		 mailreg=/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z]+){1,2}$/;
		 if(!(mailreg.test(mvalue))){
		      	alert("이메일 형식 오류");
		      	return false;
		      } 
	/* // 생년월일 정규식	
	 birvalue = $('#bir').val().trim();
	 sub = parseInt(birvalue.substring(0,4));
	 if(birvalue ==null){
	     alert("생년월일을 입력해주세요");
	     return false;
		 
	 }
	 age = 2020-sub;
	 if(age<10){
		 alert("당신의 나이는" + age + "살 입니다.가입이 불가합니다.");
		 return false;
	 }*/
	  
	
	return true;
	
}